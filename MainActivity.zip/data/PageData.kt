package com.example.care.data

data class PageData(
    val image: Int, // Referencia a R.raw.pagX
    val title: String,
    val description: String,
    val animation: Int? = null, // NUEVO: Un segundo recurso opcional para Lottie
    val imageSize: Int = 250 // NUEVO: TAMAÑO POR DEFECTO EN DP
    )