/*package com.example.care

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.care.navigation.SetupNavGraph
import com.example.care.ui.theme.CARETheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CARETheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SetupNavGraph()
                }
            }
        }
    }
} */

package com.example.care

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import com.example.care.navigation.SetupNavGraph
import com.example.care.ui.theme.CARETheme


@Composable
fun MainContent(startDestination: String) {
    CARETheme {
        SetupNavGraph(startRoute = startDestination)
    }
}
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Consultar SharedPreferences
        val sharedPreferences = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val isFirstTime = sharedPreferences.getBoolean("is_first_launch", true)

        // 2. Definir la ruta de inicio
        val startDestination = if (isFirstTime) "onboarding" else "welcome"

        setContent {
            CARETheme {
                // Pasamos la ruta decidida al NavGraph
                SetupNavGraph(startRoute = startDestination)
            }
        }
    }
}