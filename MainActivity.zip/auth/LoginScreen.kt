package com.example.care.auth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.care.components.MainButton
import com.example.care.ui.theme.AppBlue
import com.example.care.ui.theme.CARETheme

@Composable
fun LoginScreen(onBack: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
        IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = null)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text("Hola de nuevo", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Ingresa tus datos para continuar la comunicación.")

        Spacer(modifier = Modifier.height(32.dp))

        Text("Documento o Correo", fontWeight = FontWeight.Medium)
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            placeholder = { Text("Ej. 12345678 o usuario@email.com") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text("Contraseña", fontWeight = FontWeight.Medium)
        OutlinedTextField(
            value = pass,
            onValueChange = { pass = it },
            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        TextButton(
            onClick = { /* Olvido */ },
            modifier = Modifier.align(Alignment.End)
        ) {
            Text("¿Olvidaste tu contraseña?", color = AppBlue)
        }

        Spacer(modifier = Modifier.height(32.dp))

        MainButton(text = "Iniciar Sesión", onClick = { /* Login Action */ })
    }
}

@Preview(showSystemUi = true) // showSystemUi muestra la barra de estado y batería
@Composable
fun LoginPreview() {
    CARETheme {
        LoginScreen(onBack = {})
    }
}