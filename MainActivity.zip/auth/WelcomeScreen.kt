package com.example.care.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.care.R
import com.example.care.components.LoaderData
import com.example.care.components.MainButton
import com.example.care.ui.theme.AppBlue
import com.example.care.ui.theme.CARETheme // asegúrate de tener tu tema definido

@Composable
fun WelcomeScreen(onContinue: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp)
            ,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(40.dp))

        LoaderData(modifier = Modifier.size(320.dp), image = R.raw.pag4, isDynamic = true)

        // TEXTO CON COLORES AMBAS
      /*  Text(
            text = "Comunicación\nsin barreras",
            color = AppBlue,
            fontSize = 35.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            lineHeight = 34.sp
        )

       */

        Text(
            text = buildAnnotatedString {
                withStyle(style = SpanStyle(color= MaterialTheme.colorScheme.onBackground)){
                    append("Comunicación")
                }
                append("\n") //salto de linea
                withStyle(style = SpanStyle(color = AppBlue)) {
                    append("sin barreras")
                }
            },
            fontSize = 35.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            lineHeight = 38.sp // Aumentado un poco para que no se peguen las líneas
        )

        Spacer(modifier = Modifier.height(21.dp))

        Text(
            text = "Facilitando el diálogo y el cuidado. Una herramienta diseñada para conectar a pacientes y cuidadores de manera simple y efectiva.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.weight(1f))

        MainButton(text = "Continuar", onClick = onContinue)

        TextButton(onClick = { /* Login */ }) {
            Text("¿Ya tienes una cuenta? Inicia sesión", color = AppBlue)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun WelcomeScreenPreview() {
    CARETheme {
        WelcomeScreen(onContinue = {})
    }
}