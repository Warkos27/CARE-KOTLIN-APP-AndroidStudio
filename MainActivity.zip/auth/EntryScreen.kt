package com.example.care.auth

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.care.R
import com.example.care.components.MainButton
import com.example.care.ui.theme.AppBlue
import com.example.care.ui.theme.CARETheme
@Composable
fun EntryScreen(onLogin: () -> Unit, onRegister: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Aquí usa una de tus ilustraciones de fondo


        Box(modifier = Modifier.weight(1f)) {
            com.example.care.components.LoaderData(
                modifier = Modifier.fillMaxSize(),
                image = R.raw.pag5 // Ahora sí lo leerá bien como animación
            )
        }

       /* Image(
            painter = painterResource(id = R.raw.pag5), // Cambia por tu drawable
            contentDescription = null,
            modifier = Modifier.weight(1f).fillMaxWidth()
        )
*/
        Text("Bienvenido", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)

        Text(
            "Comunicación sin barreras para pacientes y cuidadores.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(vertical = 20.dp)
        )

        MainButton(text = "Iniciar Sesión", onClick = onLogin)

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(
            onClick = onRegister,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, AppBlue)
        ) {
            Text("Registrarse", color = AppBlue, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))

        TextButton(onClick = { /* Ayuda */ }) {
            Text("¿Necesitas ayuda para ingresar?", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Preview(showBackground = true, name = "Modo Claro")
@Composable
fun EntryScreenPreview() {
    CARETheme(darkTheme = false) {
        // Le pasamos llaves vacías {} porque en el preview no necesitamos que los botones hagan nada
        EntryScreen(onLogin = {}, onRegister = {})
    }
}

@Preview(showBackground = true, name = "Modo Oscuro")
@Composable
fun EntryScreenDarkPreview() {
    CARETheme(darkTheme = true) {
        EntryScreen(onLogin = {}, onRegister = {})
    }
}