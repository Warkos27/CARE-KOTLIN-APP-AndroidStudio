package com.example.care.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)


val BackgroundGray = Color(0xFFF6F7FB)
val CardGray = Color(0xFFE9EBF2)
val PrimaryBlue = Color(0xFF4C5A86)
val DotActive = Color(0xFF2DA8FF)
val DotInactive = Color(0xFFDADADA)
val TextTitle = Color(0xFF5A5A5A)
val TextBody = Color(0xFF8A8A8A)


val AppBlue = Color(0xFF00B4E5)
val AppGray = Color(0xFF757575)
val AppLightGray = Color(0xFFE0E0E0)

