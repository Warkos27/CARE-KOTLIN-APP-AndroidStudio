/*package com.example.care.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.*
import com.example.care.auth.* // Importa las pantallas de login/welcome
import com.example.care.onboarding.* // Importa MainOnBoarding

@Composable
fun SetupNavGraph() {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = "onboarding"
    ) {
        composable("onboarding") {
            MainOnBoarding(onFinished = {
                navController.navigate("welcome") { popUpTo("onboarding") { inclusive = true } }
            })
        }
        composable("welcome") { WelcomeScreen(onContinue = { navController.navigate("entry") }) }
        composable("entry") { EntryScreen(onLogin = { navController.navigate("login") }, onRegister = {}) }//
        composable("login") { LoginScreen(onBack = { navController.popBackStack() }) }
    }
} */

package com.example.care.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.care.auth.EntryScreen
import com.example.care.auth.LoginScreen
import com.example.care.auth.WelcomeScreen
import com.example.care.onboarding.MainOnBoarding

@Composable
fun SetupNavGraph(startRoute: String) { // Recibe la ruta aquí
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = startRoute // Usa la ruta dinámica
    ) {
        composable("onboarding") {
            MainOnBoarding(onFinished = {
                navController.navigate("welcome") {
                    popUpTo("onboarding") { inclusive = true }
                }
            })
        }
        composable("welcome") { WelcomeScreen(onContinue = { navController.navigate("entry") }) }
        composable("entry") { EntryScreen(onLogin = { navController.navigate("login") }, onRegister = {}) }
        composable("login") { LoginScreen(onBack = { navController.popBackStack() }) }
    }
}