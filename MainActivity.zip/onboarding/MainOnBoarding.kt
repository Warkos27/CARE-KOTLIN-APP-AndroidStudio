/*package com.example.care.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.care.R
import com.example.care.components.* // Importa PagerIndicator y MainButton
import com.example.care.data.PageData
import com.google.accompanist.pager.*

@OptIn(ExperimentalPagerApi::class)
@Composable
fun MainOnBoarding(onFinished: () -> Unit) {
    val items = listOf(
        PageData(R.raw.pag1, "Comunicación Asistida", "Expresa tus ideas fácilmente."),
        PageData(R.raw.pag2, "Monitoreo para Cuidadores", "Conexión segura en todo momento."),
        PageData(R.raw.pag3, "Inclusión Digital", "Mejora tu calidad de vida.")
    )
    val pagerState = rememberPagerState()

    Column(modifier = Modifier.fillMaxSize()) {
        OnBoardingPager(item = items, pagerState = pagerState, modifier = Modifier.weight(1f))
        PagerIndicator(size = items.size, currentPage = pagerState.currentPage)
        Box(modifier = Modifier.padding(24.dp)) {
            MainButton(
                text = if (pagerState.currentPage == items.size - 1) "Comenzar" else "Siguiente",
                onClick = { if (pagerState.currentPage == items.size - 1) onFinished() }
            )
        }
    }
} */


package com.example.care.onboarding

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext // Importante para SharedPreferences
import androidx.compose.ui.unit.dp
import com.example.care.R
import com.example.care.components.*
import com.example.care.data.PageData
import com.google.accompanist.pager.*
import androidx.compose.foundation.background // Asegúrate de tener este import
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch // 2. ASEGÚRATE DE ESTE IMPORT

@OptIn(ExperimentalPagerApi::class)
@Composable
fun MainOnBoarding(onFinished: () -> Unit) {
    val context = LocalContext.current // Obtenemos el contexto
    val scope = rememberCoroutineScope() // 3. ¡ESTA ES LA VARIABLE QUE TE FALTA!

    val items = listOf(
        PageData(R.raw.pag1, "Comunicación Asistida", "Expresa tus ideas y necesidades fácilmente. Combina pictogramas, texto y nuestra voz sintética para que todos te escuchen."),
        PageData(R.raw.pag2, "Monitoreo para Cuidadores", "Mantén la tranquilidad. Los cuidadores pueden ver tu actividad y estado en tiempo real gracias a nuestra conexión segura en la nube."),

        PageData(
            image = R.drawable.iconoss,
            title = "Inclusión Digital y\nCalidad de Vida ",
            description = "Descubre una nueva forma de interactuar con el mundo. Nuestra app promueve tu autonomía y bienestar, facilitando la conexión con quienes más te importan.", // Pásalo por nombre
            animation = R.raw.pag3,
            imageSize = 50
        )
    )
    val pagerState = rememberPagerState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        OnBoardingPager(item = items, pagerState = pagerState, modifier = Modifier.weight(1f))

        // -- AQUI ESTA EL CAMBIO --
        // Usamos un Row para ocupar todo el ancho y centrar su contenido
        Row(
            modifier = Modifier
                .fillMaxWidth(), horizontalArrangement = Arrangement.Center
        ) {
            PagerIndicator(size = items.size, currentPage = pagerState.currentPage)
        }
        Box(modifier = Modifier.padding(24.dp)) {
            MainButton(
                text = if (pagerState.currentPage == items.size - 1) "Comenzar" else "Siguiente",

                onClick = {
                    if (pagerState.currentPage == items.size - 1) {
                        // --- GUARDAR QUE YA NO ES LA PRIMERA VEZ ---
                        val sharedPreferences = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                        sharedPreferences.edit().putBoolean("is_first_launch", false).apply()

                        onFinished()
                    } else {
                        // (Opcional) Lógica para mover el pager a la siguiente hoja
                        //2. CORREGIDO_ Logica para mover a la siguiente pagina
                        scope.launch{
                            pagerState.animateScrollToPage(pagerState.currentPage + 1)
                        }
                    }
                }
            )
        }
    }
}



