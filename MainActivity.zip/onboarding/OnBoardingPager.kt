package com.example.care.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.care.components.LoaderData   // viene de components
import com.example.care.data.PageData          // viene de data
import com.google.accompanist.pager.ExperimentalPagerApi
import com.google.accompanist.pager.HorizontalPager
import com.google.accompanist.pager.PagerState

@OptIn(ExperimentalPagerApi::class)
@Composable
fun OnBoardingPager(
    item: List<PageData>,
    pagerState: PagerState,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        HorizontalPager(
            count = item.size,
            state = pagerState
        ) { page ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 40.dp), // Reducimos padding vertical para que quepa todo
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // 1. LA ANIMACIÓN (Ahora arriba del todo)
                // Si la página tiene animación, la muestra. Si no (pag 1 y 2), no ocupa espacio.
                item[page].animation?.let { animRes ->
                    LoaderData(
                        modifier = Modifier.size(220.dp), // Tamaño moderado para que no robe tanto espacio
                        image = animRes
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // 2. LA IMAGEN PNG (Abajo de la animación)
                LoaderData(
                    modifier = Modifier.size(item[page].imageSize.dp), // <--- USA EL TAMAÑO DINÁMICO
                    image = item[page].image
                )

                Spacer(modifier = Modifier.height(30.dp))

                // 3. EL TÍTULO
                Text(
                    text = item[page].title,
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.onBackground,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    lineHeight = 32.sp // Para que si el título es largo, se vea ordenado
                )

                Spacer(modifier = Modifier.height(16.dp))

                // 4. LA DESCRIPCIÓN
                Text(
                    text = item[page].description,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 16.sp, // Bajamos un poco a 16 para que no se vea tan pesado
                    lineHeight = 22.sp
                )
            }
        }
    }
}