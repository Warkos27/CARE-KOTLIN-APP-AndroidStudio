package com.example.care.components

import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.airbnb.lottie.LottieProperty
import com.airbnb.lottie.compose.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource

@Composable
fun LoaderData(
    modifier: Modifier,
    image: Int,
    isDynamic: Boolean = false
) {
    val context = LocalContext.current
    val esAnimacion = context.resources.getResourceTypeName(image) == "raw"

    if (esAnimacion) {
        // --- Si es animación, ejecutamos Lottie ---
        val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(image))

        val dynamicProperties = if (isDynamic) {
            val colorDelSistema = MaterialTheme.colorScheme.onBackground.toArgb()
            rememberLottieDynamicProperties(
                rememberLottieDynamicProperty(
                    property = LottieProperty.COLOR,
                    value = colorDelSistema,
                    keyPath = arrayOf("**", "Fill 1")
                ),
                rememberLottieDynamicProperty(
                    property = LottieProperty.COLOR,
                    value = colorDelSistema,
                    keyPath = arrayOf("**", "Fill", "**")
                )
            )
        } else {
            null
        }

        // El LottieAnimation DEBE ir dentro de las llaves del IF
        LottieAnimation(
            composition = composition,
            iterations = LottieConstants.IterateForever,
            modifier = modifier,
            dynamicProperties = dynamicProperties
        )

    } else {
        // --- Si no es animación (es drawable), mostramos la imagen ---
        Image(
            painter = painterResource(id = image),
            contentDescription = null,
            modifier = modifier
        )
    }
}



/* 1. Obtenemos el color que debe tener el contenido (negro en claro, blanco en oscuro)
val colorDelSistema = MaterialTheme.colorScheme.onBackground.toArgb()

// 2. Creamos una propiedad dinámica para cambiar todos los rellenos ("Fill") del JSON
val dynamicProperties = rememberLottieDynamicProperties(
rememberLottieDynamicProperty(
 property = LottieProperty.COLOR,
 value = colorDelSistema,
 // El asterisco "**" significa: "Busca en todas las capas"
 // "Fill 1" es el nombre que viene en tu JSON
 keyPath = arrayOf("**", "Fill 1")
),

// Por si acaso algunas capas se llaman distinto, añadimos una regla general
rememberLottieDynamicProperty(
property = LottieProperty.COLOR,
value = colorDelSistema,
keyPath = arrayOf("**", "Fill", "**")
)
)
*/
// Solo creamos las propiedades dinámicas si isDynamic es true